# progressive-income-tax-calculator
User submits form data (gross income) via form.php. Then progressive_income_tax.php receives form data and calculates the progressive income tax and effective tax rate, displaying results back to user as HTML 5 output. Displays an error message for invalid input.
